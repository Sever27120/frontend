var a=window.prompt("Saisissez un nombre");

if (a%2==0)
{
    alert("Le nombre," + a.toString() + ",est pair");
}
else
{
    alert("Le nombre ," + a.toString() + ", est impair");
}