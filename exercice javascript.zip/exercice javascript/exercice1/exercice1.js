var myVar=123;

maFonction();

function maFonction()

{
    console.log("mayVar fonction:"+myVar);

}

if(myVar>1)

{
    console.log("myVar condition:"+myVar);

}
console.log("myVar fin:"+myVar);