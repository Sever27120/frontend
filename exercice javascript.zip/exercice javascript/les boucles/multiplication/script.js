var N=prompt("Saisir le premier nombre à multiplier!");

var X=prompt ("Saisir le deuxième nombre de la multiplication!");

var i=1

while(i<=N)
{
       resultat=i*X;
       console.log (i+"x"+X+"="+resultat);
     
       
     i++; 
}




// je n'arrive pas à calculer à me calculer jusqu'au nombre chosis de départ