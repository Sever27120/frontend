//demander à l'utilisateur un chiffre

var N=prompt("Ecrire un nombre N");
// pour que l'ordinateur sort tous les chiffres avant N

for(var i=0;i<N;i++)
{
        console.log(i);
}


