function Moyenne(a, b){
    return ((a+b)/2);
}
console.log(Moyenne(10,20));