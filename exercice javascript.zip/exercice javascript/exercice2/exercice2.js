var compteur=2;

function maFonction()

{
    var myVar=456;

    console.log("myVar:"+myVar);

}

if(compteur>1)

{
    let myVar2="Wazaa!";

    console.log("myVar2:"+myVar2);
}


