var reponse1=window.prompt("saisissez votre nom");

var reponse2=window.prompt("saisissez votre prénom");

if (window.confirm ("Vous êtes une femme")==true);

alert("Bonjour," + reponse1 + "," + reponse2 + "\n Bienvenue sur notre site web!");
