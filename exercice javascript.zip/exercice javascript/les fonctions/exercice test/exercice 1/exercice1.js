function maFonction()
{
    var plop1=123;
    return plop1;
}

function maFonction2()
{
    plop2=456;
}

plop1=maFonction();

console.log("fonction1/plop1:"+plop1);

maFonction2();

console.log ("mafontion2>plop2:"+plop2);
