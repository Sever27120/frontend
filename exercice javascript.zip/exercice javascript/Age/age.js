var a=window.prompt("Saisissez votre année de naissance");
var b=window.prompt("Saisissez l'année en cours");
c=b-a

alert (c);

if(c>=18)
{
    alert ("Tu est majeur!");
}
else
{
    alert ("Tu est Mineur!");
}